// AJAX
import * as lib from './lib.js';


$(document).ready(function()
{
	lib.InitButton();
	lib.Input();
	console.log("LOad OK руус");
});
