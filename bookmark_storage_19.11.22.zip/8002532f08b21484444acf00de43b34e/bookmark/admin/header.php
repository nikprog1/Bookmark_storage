<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<?php require_once "main.php"; require_once "../start_mysql.php"; ?>
<html>
<head>
  <title><?php print $title; ?></title>
  <meta content="text/html; charset=UTF-8" http-equiv="content-type">
  <link rel="stylesheet" href="style.css" >
</head>
<body>
