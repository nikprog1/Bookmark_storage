<!DOCTYPE html>
<html lang="ru">
<?php require_once "main.php"; require_once "start_mysql.php"; ?>
<html>
<head>
  <title><?php print $title; ?></title>
  <meta charset="utf-8">
  <link rel="stylesheet" href="style.css" >
</head>
<body id="background">
